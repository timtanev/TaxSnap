HOW TO INSTALL:
1. Unzip this folder
2. Upload to GitHub (replace old files) OR drag folder to Vercel import
3. In Vercel Settings -> Environment Variables add:
   STRIPE_SECRET_KEY = your sk_live_... key from Stripe
   NEXT_PUBLIC_SITE_URL = your vercel URL
4. Deploy
5. Click Buy - it will go to Stripe checkout
