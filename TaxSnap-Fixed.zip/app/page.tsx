"use client"
import { useState } from "react"

export default function Page() {
  const [loading, setLoading] = useState(false)

  const handleBuy = async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/create-checkout-session", { method: "POST" })
      const data = await res.json()
      if (data.url) {
        window.location.href = data.url
      } else {
        alert("Error: " + data.error)
      }
    } catch (e) {
      alert("Buy failed, check Vercel logs")
      console.error(e)
    }
    setLoading(false)
  }

  return (
    <main style={{ fontFamily: "system-ui", padding: "40px", maxWidth: "600px", margin: "0 auto", textAlign: "center" }}>
      <h1 style={{ fontSize: "48px" }}>TaxSnap</h1>
      <p>Scan receipts. Auto-generate HMRC Self Assessment. £39.99/year</p>
      <div style={{ marginTop: "30px" }}>
        <button
          onClick={handleBuy}
          disabled={loading}
          style={{ padding: "18px 36px", background: "black", color: "white", borderRadius: "12px", fontSize: "20px", cursor: "pointer" }}
        >
          {loading ? "Loading..." : "Buy £39.99 / year"}
        </button>
      </div>
      <p style={{ marginTop: "20px", fontSize: "12px", color: "gray" }}>Secure checkout by Stripe</p>
    </main>
  )
}
